//9_9.cpp
#include "Calculator.h"

int main() {
	Calculator c;
	c.run();
	return 0;
}
